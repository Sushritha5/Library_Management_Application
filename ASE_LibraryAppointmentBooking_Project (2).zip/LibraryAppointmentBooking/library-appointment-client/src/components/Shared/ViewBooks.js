import NavigationBar from '.././NavigationBar'
import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../../hooks/useInput'
import { useHistory } from "react-router-dom";
import Cookies from 'js-cookie'
const rest = require('../../EndPoints')

function ViewBooks() {
    const history = useHistory();
    const [bookName, setBookName,  bindBookName, resetBookName] = useInput('')
    const [librarianId, setLibrarianId,  bindLibrarianId, resetLibrarianId] = useInput('')
    const [categoryId, setCategoryId,  bindCategoryId, resetCategoryId] = useInput('')

    const [categories, setCategories] = useState([])
    const [librarians, setLibrarians] = useState([])
    const [books, setBooks] = useState([])
    const [count, setCount] = useState(0);
    const [todayDate, setTodayDate] = useState([])
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    useEffect(() => {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        if (dd < 10) {
        dd = '0' + dd;
        }
        if (mm < 10) {
        mm = '0' + mm;
        } 
        setTodayDate(yyyy + '-' + mm + '-' + dd)
        document.getElementsByClassName("datee").value = todayDate;
        axios.get(rest.controller_librarian,header)
            .then(response => {
                console.log(response.data);
                setLibrarians(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, []);
    useEffect(() => {
        axios.get(rest.controller_category,header)
            .then(response => {
                console.log(response.data);
                setCategories(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, []);
    useEffect(() => {
        axios.get(rest.controller_book+"?librarianId="+librarianId+"&categoryId="+categoryId+"&bookName="+bookName,header)
            .then(response => {
                console.log(response.data);
                setBooks(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [count]);
    const submitForm = (e) => {
        e.preventDefault()
        setCount(count+1)
    }
    const bookAppointment = (e) => {
        e.preventDefault()
        let bookId = e.target[0].value;
        let appointmentDate = e.target[1].value;
        let librarianId = e.target[2].value;
        console.log(bookId)
        console.log(appointmentDate)
        history.push("bookSlots?librarianId="+librarianId+"&bookId="+bookId+"&appointmentDate="+appointmentDate+"&appointmentType=New Book Request"); 
    }
    return (
        <div>
            <div className='container'>
                <form onSubmit={submitForm}>
                    <div className='row'>
                        {Cookies.get('role')!='Librarian'?
                            <div className='col-md-3'>
                                <label className="form-label">Librarian</label>
                                <select  className="form-control" {...bindLibrarianId}>
                                    <option value="">All Librarians</option>
                                    {librarians.map((librarian,index)=><option key={index} value={librarian['librarianId']}>{librarian['name']} ({librarian['location']})</option>)}
                                </select>
                            </div>
                        :null}
                        
                        <div className='col-md-3'>
                            <label className="form-label">Category</label>
                            <select  className="form-control" {...bindCategoryId}>
                                <option value="">All Categories</option>
                                {categories.map((category,index)=><option key={index} value={category['categoryId']}>{category['categoryName']}</option>)}
                            </select>
                        </div>
                        <div className='col-md-3'>
                            <div className=''>
                                <label className="form-label">Book Name or Author</label>
                                <input type="text"  className="form-control"  {...bindBookName} placeholder="Enter Book Name"/>
                            </div>
                        </div>
                        <div className='col-md-3 mt-4 pt-2'>
                            <input type="submit" value="Search" class="btn btn-primary w-100"/>
                        </div>
                    </div>
                </form>
                <div className='row mt-3'>
                    {books.map((book,index)=><div key={index} className="col-md-4">
                        <div className='card2 p-3'>
                            <img src={'data:image/png;base64,'+book['picture']} style={{maxWidth:"100%",height:"200px"}}/>
                            <div className='text-center h4'><b>{book['bookName']}</b></div>
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Category</div>
                                    <div><b>{book['categoryModel']['categoryName']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Librarian</div>
                                    <div><b>{book['librarianModel']['name']} ({book['librarianModel']['location']})</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Available</div>
                                    <div><b>{book['availableBooks']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Author</div>
                                    <div><b>{book['author']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Published</div>
                                    <div><b>{book['published']}</b></div>
                                </div>
                                <div className='col-md-12 mt-3'>
                                    {Cookies.get('role')==='Student'?
                                    <form onSubmit={bookAppointment}>
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <input type="hidden" value={book['bookId']}/>
                                                <input type="date" min={todayDate} className='form-control datee'/>
                                                <input type="hidden" value={book['librarianModel']['librarianId']}/>
                                            </div>
                                            <div className='col-md-6'>
                                                <input type="submit" value="Book Appointment" class="btn btn-primary w-100"/>
                                            </div>
                                        </div>
                                    </form>:null}
                                </div>
                                <div className='col-md-12'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>About Book</div>
                                    <div>{book['aboutBook']}</div>
                                </div>
                                
                            </div>
                        </div>
                    </div>)}
                </div>
            </div>
            
        </div>
    )
}

export default ViewBooks