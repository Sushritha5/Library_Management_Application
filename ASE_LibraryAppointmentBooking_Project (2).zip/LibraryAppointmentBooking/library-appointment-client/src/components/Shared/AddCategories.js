import NavigationBar from '.././NavigationBar'
import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../../hooks/useInput'
import { useHistory } from "react-router-dom";
import Cookies from 'js-cookie'
const rest = require('../../EndPoints')


function AddCategories() {
    const [categories, setCategories] = useState([])
    const [count, setCount] = useState(0);
    const [categoryName, setCategoryName,  bindCategoryName, resetCategoryName] = useInput('')
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    useEffect(() => {
        axios.get(rest.controller_category,header)
            .then(response => {
                console.log(response.data);
                setCategories(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [count]);
    const submitForm = (e) => {
        e.preventDefault()
        let data = {
            "categoryName": categoryName
        }
        axios.post(rest.controller_category, data,header).then(response => {
            console.log(response)
            alert(response.data)
           setCount(count+1)
        }).catch(err => {
            console.log(JSON.stringify(err));
            alert('Error While Adding The Category')
        })
    }
    return (
        <div>
            <div className='row'>
                <div className='col-md-4'></div>
                <div className='col-md-4 mt-5'>
                    <div className='card2 p-3'>
                        <div className='text-center h3'>Add Category</div>
                        <form onSubmit={submitForm}>
                            <div className="mt-3">
                                <label className="form-label">Category Name</label>
                                <input type="text"  className="form-control"  {...bindCategoryName} placeholder="Enter Category Name" required/>
                            </div>
                            <button type="submit" className="btn btn-primary w-100 mt-4">Add Category</button>
                        </form>
                    </div>
                </div>
            </div>
            <div className='container'>
                <div className='row'>
                    {categories.map((category,index)=><div key={index} className='col-md-3 mt-3' >
                        <div className='card2 p-3'>
                            <div>{category['categoryName']}</div>
                        </div>
                    </div>)}
                </div>
            </div>
            
        </div>
    )
}

export default AddCategories