import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../../hooks/useInput'
import { useHistory } from "react-router-dom";
import Cookies from 'js-cookie'
import { useLocation } from 'react-router-dom';
const rest = require('../../EndPoints')

function ViewLibrarians() {
    const [librarians, setLibrarians] = useState([])
    const [count, setCount] = useState(0);
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    useEffect(() => {
        axios.get(rest.controller_librarian,header)
            .then(response => {
                console.log(response.data);
                setLibrarians(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [count]);
    const submitForm = (e) =>{
        e.preventDefault()
        let librarianId = e.target[0].value
        axios.get(rest.controller_librarian_activate+"?librarianId="+librarianId,header)
            .then(response => {
                console.log(response.data);
                alert(response.data)
                setCount(count+1)
            })
            .catch(err => {
                console.log(err)
            })
    }
    return (
        <div>
            <div className='container'>
                <div className='text-center m-3 h4'>Librarians Available</div>
                <div className='row'>
                    {librarians.map((librarian,index)=><div key={index} className="col-md-4">
                            <div className='card2 p-3'>
                                <div style={{fontSize:'70%'}}>Librarian Name</div>
                                <div>{librarian['name']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Email</div>
                                <div>{librarian['email']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Phone</div>
                                <div>{librarian['phone']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Gender</div>
                                <div>{librarian['gender']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Location</div>
                                <div>{librarian['location']}</div>
                                {librarian['status']==='Unauthorized'?<div>
                                    <form onSubmit={submitForm} className='mt-3'>
                                        <input type="hidden" value={librarian['librarianId']}/>
                                        <input type="Submit" value="Authorize" class="btn btn-success"/>
                                    </form>
                                </div>:<div className='mt-2'>
                                    <div style={{fontSize:'70%'}}>Status</div>
                                    <div>{librarian['status']}</div>
                                </div>}
                                
                            </div>
                    </div>)}
                </div>
            </div>
        </div>
    )
}

export default ViewLibrarians