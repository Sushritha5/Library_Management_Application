import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../../hooks/useInput'
import { useHistory } from "react-router-dom";
import Cookies from 'js-cookie'
import { useLocation } from 'react-router-dom';
const rest = require('../../EndPoints')

function ViewStudents() {
    const [students, setStudents] = useState([])
    const [count, setCount] = useState(0);
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    useEffect(() => {
        axios.get(rest.controller_student,header)
            .then(response => {
                console.log(response.data);
                setStudents(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [count]);
    const submitForm = (e) =>{
        e.preventDefault()
        let studentId = e.target[0].value
        axios.get(rest.controller_student_activate+"?studentId="+studentId,header)
            .then(response => {
                console.log(response.data);
                alert(response.data)
                setCount(count+1)
            })
            .catch(err => {
                console.log(err)
            })
    }
    return (
        <div>
            <div className='container'>
                <div className='text-center m-3 h4'>Students Available</div>
                <div className='row'>
                    {students.map((student,index)=><div key={index} className="col-md-4">
                            <div className='card2 p-3'>
                                <div style={{fontSize:'70%'}}>Student Name</div>
                                <div>{student['name']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Email</div>
                                <div>{student['email']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Phone</div>
                                <div>{student['phone']}</div>
                                <div className='mt-2' style={{fontSize:'70%'}}>Gender</div>
                                <div>{student['gender']}</div>
                                
                                {student['status']==='Unauthorized'?<div>
                                    <form onSubmit={submitForm} className='mt-3'>
                                        <input type="hidden" value={student['studentId']}/>
                                        <input type="Submit" value="Authorize" class="btn btn-success"/>
                                    </form>
                                </div>:<div>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Status</div>
                                    <div>{student['status']}</div>
                                </div>}
                                
                            </div>
                    </div>)}
                </div>
            </div>
        </div>
    )
}

export default ViewStudents