import React, { useEffect } from 'react'
import Logout from './Logout'
import Cookies from 'js-cookie'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    Redirect,
    useRouteMatch,
    useParams, useHistory
} from "react-router-dom";
import ViewLibrarians from './Shared/ViewLibrarians';
import Home from './Student/Home';
import ViewBooks from './Shared/ViewBooks';
import ViewAppointments from './Student/ViewAppointments';
import NavigationBar from './Student/NavigationBar';
import BookSlot from './Student/BookSlot';


function StudentHome() {
    let match = useRouteMatch();
    return (
        <div>
            <NavigationBar  />
            <Switch>
                    <div>
                        <Route path={`${match.path}/home`} component={Home} />
                        <Route path={`${match.path}/viewLibrarians`} component={ViewLibrarians} />
                        <Route path={`${match.path}/viewBooks`} component={ViewBooks} />
                        <Route path={`${match.path}/bookSlots`} component={BookSlot} />
                        <Route path={`${match.path}/viewAppointments`} component={ViewAppointments} />
                        <Route path={`${match.path}/logout`} component={Logout} />
                        <Route exact path="" render={() => { return (<Redirect to={`${match.url}/home`}/>  ) }} />
                    </div>
            </Switch>
        </div>
    )
}

export default StudentHome