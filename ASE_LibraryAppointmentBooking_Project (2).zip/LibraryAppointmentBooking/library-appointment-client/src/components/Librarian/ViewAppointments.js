import React from 'react'

function ViewAppointments() {
    return (
        <div>
            <h1>Something Went ViewAppointments....</h1>
        </div>
    )
}

export default ViewAppointments