import NavigationBar from '.././NavigationBar'
import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../../hooks/useInput'
import { useHistory } from "react-router-dom";
import Cookies from 'js-cookie'
const rest = require('../../EndPoints')

function AddBooks() {
    const [categories, setCategories] = useState([])
    const [bookName, setBookName,  bindBookName, resetBookName] = useInput('')
    const [categoryId, setCategoryId,  bindCategoryId, resetCategoryId] = useInput('')
    const [availableBooks, setAvailableBooks,  bindAvailableBooks, resetAvailableBooks] = useInput('')
    const [author, setAuthor,  bindAuthor, resetAuthor] = useInput('')
    const [published, setPublished,  bindPublished, resetPublished] = useInput('')
    const [aboutBook, setAboutBook,  bindAboutBook, resetAboutBook] = useInput('')
    const [state, setState]  = useState();
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    const fileSelectedHandler = (event) => {
        setState({
            selectedFile: event.target.files[0],
            filename: event.target.files
        })
    }
    useEffect(() => {
        axios.get(rest.controller_category,header)
            .then(response => {
                console.log(response.data);
                setCategories(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, []);
    const submitForm = (e) => {
        e.preventDefault()
        let formData = new FormData();
        formData.append('bookName', bookName);
        formData.append('categoryId', categoryId);
        formData.append('availableBooks', availableBooks);
        formData.append('author', author);
        formData.append('published', published);
        formData.append('aboutBook', aboutBook);
        formData.append('file', state.selectedFile);
        axios.post(rest.controller_book, formData, header).then(response => {
            console.log(response)
            alert(response.data)
            setBookName('')
            setCategoryId('')
            setAvailableBooks('')
            setAuthor('')
            setPublished('')
            setAboutBook('')
        }).catch(err => {
            alert('Error While Adding The user')
        })
    }
    return (
        <div>
            <div className='container'>
                <div className='card2 mt-5 p-4'>
                    <div className='text-center h4 mt-4'>Add New Books</div>
                    <form onSubmit={submitForm}>
                        <div className='row'>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">Book Name</label>
                                <input type="text"  className="form-control"  {...bindBookName} placeholder="Enter Book Name" required/>
                            </div>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">Choose Category</label>
                                <select className="form-control"  {...bindCategoryId} required>
                                    <option value="">Choose Book Category</option>
                                    {categories.map((category,index)=><option key={index} value={category['categoryId']}>
                                        {category['categoryName']}
                                    </option>)}
                                </select>
                            </div>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">Available Book Count</label>
                                <input type="number"  className="form-control" min="1"  {...bindAvailableBooks} placeholder="Enter Available Books" required/>
                            </div>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">Author</label>
                                <input type="text"  className="form-control"  {...bindAuthor} placeholder="Enter Author Name" required/>
                            </div>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">Published Year</label>
                                <input type="number"  className="form-control" min="1900"  max="2022" {...bindPublished} placeholder="Enter Published Year" required/>
                            </div>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">Choose Picture</label>
                                <input type="file"  onChange={fileSelectedHandler} className="form-control" required/>
                            </div>
                            <div className='col-md-6 mt-3'>
                                <label className="form-label">About Book</label>
                                <textarea {...bindAboutBook} required placeholder='About book' className='form-control'></textarea>
                            </div>
                            <div className='col-md-6 mt-5'>
                                <input type="Submit" value="Add Book" class="btn btn-primary mt-3 w-100"/>
                            </div>
                        </div>
                    </form>
                </div>
                
            </div>
            
        </div>
    )
}

export default AddBooks
