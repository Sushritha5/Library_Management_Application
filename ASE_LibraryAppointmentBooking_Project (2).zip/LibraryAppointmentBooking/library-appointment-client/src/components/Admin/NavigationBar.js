import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link, useRouteMatch
  } from "react-router-dom";


function NavigationBar() {
    let match = useRouteMatch();
    console.log(match.path)
    return ( 
        <div>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <Link to={`${match.url}/home`}  className="nav-link">Home</Link>
                </li>
                <li class="nav-item">
                    <Link to={`${match.url}/viewStudents`}  className="nav-link">Students</Link>
                </li>
                <li class="nav-item">
                    <Link to={`${match.url}/viewLibrarians`} className="nav-link">Librarians</Link>
                </li>
                <li class="nav-item">
                    <Link to={`${match.url}/addCategories`} className="nav-link">Categories</Link>
                </li>
                <li className="nav-item">
                    <Link to={`${match.url}/logout`}  className="nav-item nav-link">Logout</Link>
                </li>
            </ul>
            </div>
        </nav>
        </div>
    )
}

export default NavigationBar
