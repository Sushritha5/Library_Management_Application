import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../hooks/useInput'
import { useHistory } from "react-router-dom";
import NavigationBar from './NavigationBar'
import img1 from '../asserts/l3.jpeg'
const rest = require('../EndPoints')

function LibrarianRegistration() {
    const history = useHistory();
    const [name, setName,  bindName, resetName] = useInput('')
    const [phone, setPhone, bindPhone, resetPhone] = useInput('')
    const [email, setEmail,  bindEmail, resetEmail] = useInput('')
    const [password, setPassword, bindPassword, resetPassword] = useInput('')
    const [gender, setGender, bindGender, resetGender] = useInput('')
    const [location, setLocation, bindLocation, resetLocation] = useInput('')

    const submitForm = (e) => {
        e.preventDefault()
        let data = {
            "name": name,
            "email": email,
            "phone": phone,
            "password": password,
            "gender": gender,
            "location": location
        }
        console.log(data);
        axios.post(rest.controller_lreg, data).then(response => {
            console.log(response)
            alert(response.data)
            history.push("./home");  
        }).catch(err => {
            console.log(JSON.stringify(err));
            alert('Error While Adding The user')
        })
    }
    return (
        <div style={{backgroundImage:'url('+img1+')',height:'100vh'}}>
            <NavigationBar/>
            <div className='row'>
                <div className='col-md-4'></div>
                <div className='col-md-4 mt-5'>
                    <div className='card2 p-3'>
                        <div className='text-center h3'>New Librarian</div>
                        <form onSubmit={submitForm}>
                            <div className="mt-3">
                                <label className="form-label">Name:</label>
                                <input type="text" className="form-control" {...bindName}  placeholder="Enter Librarian Name" required/>
                            </div>
                            <div className="mt-3">
                                <label className="form-label">Email:</label>
                                <input type="email" className="form-control" {...bindEmail}  placeholder="Enter Email Address" required/>
                            </div>
                            <div className="mt-3">
                                <label className="form-label">Phone:</label>
                                <input type="number" className="form-control"  {...bindPhone} placeholder="Enter Phone Number" required/>
                            </div>
                            <div className="mt-3">
                                <label className="form-label">Password:</label>
                                <input type="password" className="form-control" {...bindPassword} placeholder="Enter password" required/>
                            </div>
                            <div className="mt-3">
                                <label className="form-label">Location</label>
                                <input type="text" className="form-control" {...bindLocation} placeholder="Enter Location" required/>
                            </div>
                            <div className="mt-3">
                                <label  className="form-label">Gender</label>
                                <select className='form-control' {...bindGender} required>
                                    <option value="">Choose Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <button type="submit" className="btn btn-primary w-100 mt-4">Register Librarian</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default LibrarianRegistration