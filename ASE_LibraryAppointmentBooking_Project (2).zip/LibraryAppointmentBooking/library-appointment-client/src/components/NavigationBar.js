import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link, useRouteMatch
  } from "react-router-dom";


function NavigationBar() {
    let match = useRouteMatch();
    console.log(match.path)
    return ( 
        <div>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <Link to='/home'  className="nav-link">Home</Link>
                </li>
                <li class="nav-item">
                    <Link to='/lreg'  className="nav-link">New Librarian</Link>
                </li>
                <li class="nav-item">
                    <Link to='/sreg'  className="nav-link">New Student</Link>
                </li>
            </ul>
            </div>
        </nav>
        </div>
    )
}

export default NavigationBar
