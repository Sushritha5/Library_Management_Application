import React, { useEffect } from 'react'
import Logout from './Logout'
import Cookies from 'js-cookie'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    Redirect,
    useRouteMatch,
    useParams, useHistory
} from "react-router-dom";
import ViewStudents from './Shared/ViewStudents';
import AddCategories from './Shared/AddCategories';
import AddBooks from './Librarian/AddBooks';
import ViewBooks from './Shared/ViewBooks';
import Home from './Librarian/Home';
import NavigationBar from './Librarian/NavigationBar';
import ViewAppointments from './Student/ViewAppointments';

function LibrarianHome() {
    let match = useRouteMatch();
    return (
        <div>
            <NavigationBar  />
            <Switch>
                    <div>
                        <Route path={`${match.path}/home`} component={Home} />
                        <Route path={`${match.path}/viewStudents`} component={ViewStudents} />
                        <Route path={`${match.path}/addBooks`} component={AddBooks} />
                        <Route path={`${match.path}/viewBooks`} component={ViewBooks} />
                        <Route path={`${match.path}/viewAppointments`} component={ViewAppointments} />
                        <Route path={`${match.path}/addCategories`} component={AddCategories} />
                        <Route path={`${match.path}/logout`} component={Logout} />
                        <Route exact path="" render={() => { return (<Redirect to={`${match.url}/home`}/>  ) }} />
                    </div>
            </Switch>
        </div>
    )
}

export default LibrarianHome