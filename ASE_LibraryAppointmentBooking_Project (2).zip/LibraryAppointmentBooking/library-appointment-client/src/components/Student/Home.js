import React from 'react'

function Home() {
    return (
        <div className='mt-5'>
            <div className='text-center mt-5 h1'>Student Home</div>
        </div>
    )
}

export default Home