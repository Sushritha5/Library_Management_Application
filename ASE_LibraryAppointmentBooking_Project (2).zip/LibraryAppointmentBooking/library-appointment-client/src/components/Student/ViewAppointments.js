import React, { useEffect, useRef, useState } from 'react'
import useInput from '../../hooks/useInput'
import axios from 'axios'
import Cookies from 'js-cookie'
import { useHistory } from 'react-router-dom'
import qs from 'qs'
const rest = require('../../EndPoints')

function ViewAppointments() {
    const history = useHistory();
    const [appointments, setAppointments] = useState([])
    const [count, setCount] = useState(0);
    const [todayDate, setTodayDate] = useState([])
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    useEffect(() => {
        var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
            dd = '0' + dd;
            }
            if (mm < 10) {
            mm = '0' + mm;
            } 
        setTodayDate(yyyy + '-' + mm + '-' + dd)
        let today2 = null
        if(Cookies.get('role')==='Librarian'){
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
            dd = '0' + dd;
            }
            if (mm < 10) {
            mm = '0' + mm;
            } 
            
            if(document.getElementById("date").value==''){
                today2 = yyyy + '-' + mm + '-' + dd;
            }else{
                today2 = document.getElementById("date").value;
            }
            document.getElementById("date").value = yyyy + '-' + mm + '-' + dd;
        }
        axios.get(rest.controller_appointment+"?appointmentDate="+today2,header)
            .then(response => {
                console.log(response.data);
                setAppointments(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, [count]);
    
    const dateChanged =(e) =>{
        let appointmentDate = e.target.value
        axios.get(rest.controller_appointment+"?appointmentDate="+appointmentDate,header)
            .then(response => {
                console.log(response.data);
                setAppointments(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }
    const setSatus = (e) => {
        e.preventDefault()
        let appointmentId = e.target[0].value;
        let status = e.target[1].value;
        console.log(status)
        axios.get(rest.controller_setStatus+"?appointmentId="+appointmentId+"&status="+status,header)
            .then(response => {
                console.log(response.data);
                alert(response.data)
                setCount(count+1)
            })
            .catch(err => {
                console.log(err)
            })
    }
    const bookAppointment = (e) => {
        e.preventDefault()
        let bookId = e.target[0].value;
        let appointmentDate = e.target[1].value;
        let librarianId = e.target[2].value;
        console.log(bookId)
        console.log(appointmentDate)
        history.push("bookSlots?librarianId="+librarianId+"&bookId="+bookId+"&appointmentDate="+appointmentDate+"&appointmentType=Book Return Request"); 
    }
    return (
        <div className='container'>
            <div className='row'>
                <div className='col-md-3'>
                {Cookies.get('role')==='Librarian'?<div>
                    <input type="date" onChange={dateChanged} id="date" className='form-control m-3'/>
                </div>:null}
                </div>
                <div className='col-md-6 text-center h3 mt-2'>Your Appointment</div>
            </div>
            <div className='row'>
            {appointments.map((appointment,index)=><div className='col-md-6'>
                <div className='card p-3 mt-3'>
                    <div className='row'>
                        <div className='col-md-6'>
                        <img src={'data:image/png;base64,'+appointment['bookModel']['picture']} style={{maxWidth:"100%",height:"200px"}}/>
                            <div className='text-center h4'><b>{appointment['bookModel']['bookName']}</b></div>
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Category</div>
                                    <div><b>{appointment['bookModel']['categoryModel']['categoryName']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Librarian</div>
                                    <div><b>{appointment['bookModel']['librarianModel']['name']} ({appointment['bookModel']['librarianModel']['location']})</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Available</div>
                                    <div><b>{appointment['bookModel']['availableBooks']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Author</div>
                                    <div><b>{appointment['bookModel']['author']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Published</div>
                                    <div><b>{appointment['bookModel']['published']}</b></div>
                                </div>
                                <div className='col-md-12'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>About Book</div>
                                    <div>{appointment['bookModel']['aboutBook']}</div>
                                </div>
                                
                            </div>
                        </div>
                        <div className='col-md-6'>
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Slot</div>
                                    <div><b>{appointment['slot']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Slot Number</div>
                                    <div><b>{appointment['slotNumber']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Appointment Date</div>
                                    <div><b>{appointment['appointmentDate']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Booked Date</div>
                                    <div style={{fontSize:'60%'}}><b>{appointment['bookedDate']}</b></div>
                                </div>
                                {appointment['issuedDate']!=null?
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Issued Date</div>
                                    <div><b>{appointment['issuedDate']}</b></div>
                                </div>:null}
                                {appointment['issuedDate']!=null?
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Return Date</div>
                                    <div><b>{appointment['returnDate']}</b></div>
                                </div>:null}
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Appointment Type</div>
                                    <div style={{fontSize:'80%'}}><b>{appointment['appointmentType']}</b></div>
                                </div>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}} className='mt-3'>Status</div>
                                    <div style={{fontSize:'80%'}}><b>{appointment['status']}</b></div>
                                </div>
                            </div>
                            <hr/>
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}}>Librarian Name</div>
                                    <div>{appointment['librarianModel']['name']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Email</div>
                                    <div>{appointment['librarianModel']['email']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Phone</div>
                                    <div>{appointment['librarianModel']['phone']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Gender</div>
                                    <div>{appointment['librarianModel']['gender']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Location</div>
                                    <div>{appointment['librarianModel']['location']}</div>
                                </div>
                                <div className='col-md-12'>
                                    {Cookies.get('role')==='Librarian'&&appointment['status']==='Appointment Booked' && appointment['appointmentType']==='New Book Request'?
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <form onSubmit={setSatus}>
                                                    <input type="hidden" value={appointment['appointmentId']}/>
                                                    <input type="hidden" value="Book Assigned"/>
                                                    <input type="submit" value="Assign Book" class="btn btn-success w-100 mt-3"/>
                                                </form>
                                            </div>
                                            <div className='col-md-6'>
                                                <form onSubmit={setSatus}>
                                                    <input type="hidden" value={appointment['appointmentId']}/>
                                                    <input type="hidden" value="Appointment Rejected"/>
                                                    <input type="submit" value="Reject Request" class="btn btn-danger w-100 mt-3"/>
                                                </form>
                                            </div>
                                        </div>
                                    :null}
                                    {Cookies.get('role')==='Librarian'&&appointment['status']==='Appointment Booked' && appointment['appointmentType']==='Book Return Request'?
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <form onSubmit={setSatus}>
                                                    <input type="hidden" value={appointment['appointmentId']}/>
                                                    <input type="hidden" value="Book Returned"/>
                                                    <input type="submit" value="Collect Book" class="btn btn-success w-100 mt-3"/>
                                                </form>
                                            </div>
                                        </div>
                                    :null}
                                </div>
                            </div>
                            <hr/>
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div style={{fontSize:'70%'}}>Student Name</div>
                                    <div>{appointment['studentModel']['name']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Email</div>
                                    <div>{appointment['studentModel']['email']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Phone</div>
                                    <div>{appointment['studentModel']['phone']}</div>
                                </div>
                                <div className='col-md-6'>
                                    <div className='mt-2' style={{fontSize:'70%'}}>Gender</div>
                                    <div>{appointment['studentModel']['gender']}</div>
                                </div>
                                <div className='col-md-12'>
                                    {Cookies.get('role')==='Student' && appointment['status']==='Appointment Booked' && appointment['appointmentType']==='New Book Request'?
                                    <form onSubmit={setSatus}> 
                                        <input type="hidden" value={appointment['appointmentId']}/>
                                        <input type="hidden" value="Appointment Cancelled"/>
                                        <input type="submit" value="Cancel Appointment" class="btn btn-danger w-100 mt-3"/>
                                    </form>
                                    :null}
                                    {Cookies.get('role')==='Student'&&appointment['status']==='Book Assigned'?
                                    <form onSubmit={bookAppointment}>
                                    <div className='row'>
                                        <div className='col-md-6'>
                                            <input type="hidden" value={appointment['bookModel']['bookId']}/>
                                            <input type="date"  min={todayDate} className='form-control datee'/>
                                            <input type="hidden" value={appointment['bookModel']['librarianModel']['librarianId']}/>
                                        </div>
                                        <div className='col-md-6'>
                                            <input type="submit" value="Book Appointment" class="btn btn-primary w-100"/>
                                        </div>
                                    </div>
                                </form>
                                    :null}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>)}
            </div>
        </div>
    )
}

export default ViewAppointments