import React, { useEffect, useRef, useState } from 'react'
import useInput from '../../hooks/useInput'
import axios from 'axios'
import Cookies from 'js-cookie'
import { useHistory } from 'react-router-dom'
import qs from 'qs'
const rest = require('../../EndPoints')

function BookSlot(props) {
    const history = useHistory();
    let bookId=qs.parse(props.location.search, { ignoreQueryPrefix: true })['bookId']
    let appointmentDate=qs.parse(props.location.search, { ignoreQueryPrefix: true })['appointmentDate']
    let librarianId=qs.parse(props.location.search, { ignoreQueryPrefix: true })['librarianId']
    let appointmentType=qs.parse(props.location.search, { ignoreQueryPrefix: true })['appointmentType']

    console.log(appointmentDate)
    const [slots, setSlots] = useState([])
    const header = {
        headers: {
            "Content-type": "Application/json",
            "Authorization": `Bearer ${Cookies.get('token')}`
        }
    }
    useEffect(() => {
        axios.get(rest.controller_slots+"?appointmentDate="+appointmentDate+"&librarianId="+librarianId,header)
            .then(response => {
                console.log(response.data);
                setSlots(response.data)
            })
            .catch(err => {
                console.log(err)
            })
    }, []);
    const confirmAppointment = (e) => {
        e.preventDefault()
        let slot = e.target[0].value
        let slotNumber = e.target[1].value;
        let data = {
            "bookId": bookId,
            "appointmentDate": appointmentDate,
            "slot": slot,
            "librarianId": librarianId,
            "appointmentType":appointmentType,
            "slotNumber": slotNumber
        }
        axios.post(rest.controller_appointment, data,header).then(response => {
            console.log(response)
             alert(response.data)
             history.push("viewAppointments"); 
        }).catch(err => {
            console.log(JSON.stringify(err));
            alert('Error While Adding The Category')
        })
        console.log(data)
    }
    return (
        <div>
            <div className='container'>
                <div className='row'>
                    {slots.map((slot,index)=>
                    <div className='col-md-2' key={index}>
                        {slot['status']!='Available'?<div>
                            <div className='card mt-3 p-3 bg-info'>
                                <div className=''>Slot</div>
                                <div>{slot['slot']}</div>
                                {/* <form onSubmit={confirmAppointment}>
                                    <input type="hidden" value={slot['slot']}/>
                                    <input type="submit" value="Select Slot" className='btn btn-primary mt-3'/>
                                </form> */}
                            </div>
                        </div>:<div>
                        <div className='card mt-3 p-3'>
                                <div className=''>Slot</div>
                                <div>{slot['slot']}</div>
                                <form onSubmit={confirmAppointment}>
                                    <input type="hidden" value={slot['slot']}/>
                                    <input type="hidden" value={slot['slotNumber']}/>
                                    <input type="submit" value="Select Slot" className='btn btn-primary mt-3'/>
                                </form>
                            </div>
                        </div>}
                        
                    </div>
                    )}
                </div>
            </div>
        </div>
    )
}

export default BookSlot