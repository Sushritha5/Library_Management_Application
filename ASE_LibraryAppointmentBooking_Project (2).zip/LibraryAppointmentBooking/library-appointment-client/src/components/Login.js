import NavigationBar from './NavigationBar'
import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'
import useInput from '../hooks/useInput'
import { useHistory } from "react-router-dom";
import Cookies from 'js-cookie'
import img1 from '../asserts/l1.jpeg'
const rest = require('../EndPoints')

function Login() {
    const history = useHistory();
    const [email, setEmail,  bindEmail, resetEmail] = useInput('')
    const [password, setPassword, bindPassword, resetPassword] = useInput('')
    const [role, setRole, bindRole, resetRole] = useInput('')

    const submitForm = (e) => {
        e.preventDefault()
        let data = {
            "email": email,
            "password": password,
        }
        console.log(data);
        axios.post(rest.controller_authenticate,{"username":email,"password":password,"userType":role})
            .then(response => {
                console.log(response.data);
                if(response.data=="Invalid Role"){
                    alert("Invalid Role")
                }else if(response.data==='You are Unauthorized'){
                    alert("You are Unauthorized")
                } else {
                    Cookies.set('token',response.data.token)
                    Cookies.set('userType',role)
                    Cookies.set('role',role)
                    history.push("/"+role);   
                }
            })
            .catch((err) => {
                console.log(err.response.data.error);
                alert("Invalid Login Details")
            })
        
    }
    return (
        <div>
            <NavigationBar/>
            <div className='row' style={{backgroundImage:'url('+img1+')',height:'100vh'}}>
                <div className='col-md-4'></div>
                <div className='col-md-4 mt-5'>
                    <div className='card2 p-3'>
                        <div className='text-center h3'>Login Here</div>
                        <form onSubmit={submitForm}>
                            <div className="mt-3">
                                <label className="form-label">Email:</label>
                                <input type="email"  className="form-control"  {...bindEmail} placeholder="Enter Email Address" required/>
                            </div>
                            <div className="mt-3">
                                <label className="form-label">Password:</label>
                                <input type="password" className="form-control" {...bindPassword} placeholder="Enter password" required/>
                            </div>
                            <div className="mt-3">
                                <label  className="form-label">Choose Role:</label>
                                <select className='form-control' {...bindRole} required>
                                    <option value="">Choose Role</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Librarian">Librarian</option>
                                    <option value="Student">Student</option>
                                </select>
                            </div>
                            <button type="submit" className="btn btn-primary w-100 mt-4">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login