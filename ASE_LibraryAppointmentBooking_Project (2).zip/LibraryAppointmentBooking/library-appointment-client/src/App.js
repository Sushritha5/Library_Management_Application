import React, { useEffect } from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
  useRouteMatch,
  useParams
} from "react-router-dom";
import Login from './components/Login';
import LibrarianRegistration from './components/LibrarianRegistration';
import StudentRegistration from './components/StudentRegistration';
import Logout from './components/Logout';
import AdminHome from './components/AdminHome';
import LibrarianHome from './components/LibrarianHome';
import StudentHome from './components/StudentHome';
import NotFound from './components/NotFound';

function App() {
  return (
    <div className="App">
      <Router>
        <div className="App">
          <Route path="/home" component={Login} />
          <Route path="/lreg" component={LibrarianRegistration} />
          <Route path="/sreg" component={StudentRegistration} />
          <Route path="/logout" component={Logout} />
          <Route path="/admin" component={AdminHome} />
          <Route path="/librarian" component={LibrarianHome} />
          <Route path="/student" component={StudentHome} />
          <Route path="/notFound" component={NotFound} />
          <Route exact path="/" render={() => { return (<Redirect to="/home"/>  ) }} />
        </div>
      </Router>
    </div>
  );
}

export default App;
