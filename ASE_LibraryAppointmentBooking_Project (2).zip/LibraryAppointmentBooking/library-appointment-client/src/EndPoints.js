const endPoint = 'http://localhost:8080/'
exports.controller_sreg = endPoint+'sreg'
exports.controller_lreg = endPoint+'lreg'
exports.controller_authenticate = endPoint+'authenticate'
exports.controller_librarian = endPoint+'librarian'
exports.controller_librarian_activate = endPoint+'librarianActivate'
exports.controller_student = endPoint+'student'
exports.controller_student_activate = endPoint+'studentActivate'
exports.controller_category = endPoint+'category'
exports.controller_book = endPoint+'book'
exports.controller_slots = endPoint+'slots'
exports.controller_appointment = endPoint+'appointment'
exports.controller_setStatus = endPoint+'setStatus'











