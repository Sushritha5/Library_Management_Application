package library.appointment.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import library.appointment.model.BookModel;
import library.appointment.model.CategoryModel;
import library.appointment.model.LibrarianModel;
import library.appointment.model.UserDao;
import library.appointment.repositories.BookRepository;
import library.appointment.repositories.CategoryRepository;
import library.appointment.repositories.LibrarianRepository;
import library.appointment.repositories.UserRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Autowired
	private LibrarianRepository librarianRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Value("${bookdImagePath}")
	String bookdImagePath ;

	public String addBook(BookModel bookModel, String name) {
		LibrarianModel librarianModel = librarianRepository.findByEmail(name);
		CategoryModel categoryModel = categoryRepository.findById(bookModel.getCategoryId()).get();
		bookModel.setLibrarianModel(librarianModel);
		bookModel.setCategoryModel(categoryModel);
		bookRepository.save(bookModel);
		return "Book Added Successfully";
	}

	public List<BookModel> getBooks(String librarianId, String categoryId, String bookName, String name) {
		System.out.println(librarianId);
		List<BookModel> bookModelList= new ArrayList<>();
		List<BookModel> bookModelList2= new ArrayList<>();
		UserDao userDao = userRepository.findByUsername(name);
		LibrarianModel librarianModel = null;
		CategoryModel categoryModel = null;
		if(userDao.getRole().equalsIgnoreCase("Librarian")) {
			librarianModel = librarianRepository.findByEmail(name);
		}else {
			if(librarianId!="") {
				librarianModel = librarianRepository.findById(Long.parseLong(librarianId)).get();
			}
		}
		if(categoryId!="") {
			categoryModel = categoryRepository.findById(Long.parseLong(categoryId)).get();
		}
		if(librarianModel==null && categoryModel==null && bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findAll();
		}else if(librarianModel==null && categoryModel==null && !bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByBookNameLikeOrAuthorLike("%"+bookName+"%","%"+bookName+"%");
		}else if(librarianModel==null && categoryModel!=null && bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByCategoryModel(categoryModel);
		}else if(librarianModel==null && categoryModel!=null && !bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByCategoryModelAndBookNameLikeOrAuthorLike(categoryModel,"%"+bookName+"%","%"+bookName+"%");
		}else if(librarianModel!=null && categoryModel==null && bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByLibrarianModel(librarianModel);
		}else if(librarianModel!=null && categoryModel==null && !bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByLibrarianModelAndBookNameLikeOrAuthorLike(librarianModel,"%"+bookName+"%","%"+bookName+"%");
		}else if(librarianModel!=null && categoryModel!=null && bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByLibrarianModelAndCategoryModel(librarianModel,categoryModel);
		}else if(librarianModel!=null && categoryModel!=null && !bookName.equalsIgnoreCase("")) {
			bookModelList = bookRepository.findByLibrarianModelAndCategoryModelAndBookNameLikeOrAuthorLike(librarianModel,categoryModel,"%"+bookName+"%","%"+bookName+"%");
		}
		
		Iterator<BookModel> bookModelIterator =  bookModelList.iterator();
		while (bookModelIterator.hasNext()) {
			BookModel bookModel = (BookModel) bookModelIterator.next();
			try {
				File file=new File(bookdImagePath+"/"+bookModel.getPicture());
			    InputStream in = new FileInputStream(file);
			    bookModel.setPicture(Base64.getEncoder().encodeToString(IOUtils.toByteArray(in)));
			} catch (Exception e) {
				System.out.println(e);
			}
	
			bookModelList2.add(bookModel);
		}
		return bookModelList2;
	}
		
}
