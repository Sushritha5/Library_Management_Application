package library.appointment.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import library.appointment.model.AppointmentModel;
import library.appointment.model.BookModel;
import library.appointment.model.LibrarianModel;
import library.appointment.model.SlotModel;
import library.appointment.model.StudentModel;
import library.appointment.model.UserDao;
import library.appointment.repositories.AppointmentRepository;
import library.appointment.repositories.BookRepository;
import library.appointment.repositories.LibrarianRepository;
import library.appointment.repositories.StudentRepository;
import library.appointment.repositories.UserRepository;

@Service
public class AppointmentService {
	@Autowired
	private AppointmentRepository appointmentRepository;
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private LibrarianRepository librarianRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Value("${opening.time}")
	String openingTime ;
	
	@Value("${closing.time}")
	String closingTime ;
	
	@Value("${slot.duration}")
	String duration ;
	
	@Value("${bookdImagePath}")
	String bookdImagePath ;
	
	public List<SlotModel> getSlots(String librarianId, String appointmentDate,String name) {
		String weekDays[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
		UserDao userDao = userRepository.findByUsername(name);
		List<SlotModel> slotList = new ArrayList<SlotModel>();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			Date appointmentDate2 = formatter.parse(appointmentDate);
			String weekDay = weekDays[appointmentDate2.getDay()];
			System.out.println(weekDay);
			LibrarianModel librarianModel = null;
			if(userDao.getRole().equalsIgnoreCase("Librarian")) {
				librarianModel = librarianRepository.findByEmail(name);
			}else {
				librarianModel = librarianRepository.findById(Long.parseLong(librarianId)).get();
			}
			
			SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");  
			String strTodayOpenDate = formatter2.format(new Date())+" "+openingTime;
			String strTodayCloseDate = formatter2.format(new Date())+" "+closingTime;
			SimpleDateFormat formatter3 = new SimpleDateFormat("dd/MM/yyyy HH:mm");  
			Date todayOpenDate = formatter3.parse(strTodayOpenDate);
			Date todayCloseDate = formatter3.parse(strTodayCloseDate);
			System.out.println(todayOpenDate);
			System.out.println(todayCloseDate);
			long i = 1;
			while(todayOpenDate.before(todayCloseDate)) {
				String slotStart = null;
				String slotEnd = null;
				if(todayOpenDate.getHours()<10 && todayOpenDate.getMinutes()<10) {
					slotStart = "0"+todayOpenDate.getHours()+":0"+todayOpenDate.getMinutes();
				}else if(todayOpenDate.getHours()<10 && todayOpenDate.getMinutes()>=10) {
					slotStart = "0"+todayOpenDate.getHours()+":"+todayOpenDate.getMinutes();
				}else if(todayOpenDate.getHours()>=10 && todayOpenDate.getMinutes()<10) {
					slotStart = ""+todayOpenDate.getHours()+":0"+todayOpenDate.getMinutes();
				}else if(todayOpenDate.getHours()>=10 && todayOpenDate.getMinutes()>=10) {
					slotStart = ""+todayOpenDate.getHours()+":"+todayOpenDate.getMinutes();
				}
				todayOpenDate.setTime(todayOpenDate.getTime() + TimeUnit.MINUTES.toMillis(Long.parseLong(duration)));
				if(todayOpenDate.getHours()<10 && todayOpenDate.getMinutes()<10) {
					slotEnd = "0"+todayOpenDate.getHours()+":0"+todayOpenDate.getMinutes();
				}else if(todayOpenDate.getHours()<10 && todayOpenDate.getMinutes()>=10) {
					slotEnd = "0"+todayOpenDate.getHours()+":"+todayOpenDate.getMinutes();
				}else if(todayOpenDate.getHours()>=10 && todayOpenDate.getMinutes()<10) {
					slotEnd = ""+todayOpenDate.getHours()+":0"+todayOpenDate.getMinutes();
				}else if(todayOpenDate.getHours()>=10 && todayOpenDate.getMinutes()>=10) {
					slotEnd = ""+todayOpenDate.getHours()+":"+todayOpenDate.getMinutes();
				}
				SlotModel slotModel = new SlotModel();
				slotModel.setSlot(slotStart+" - "+slotEnd);
				List<String> statuses = new ArrayList<>();
				statuses.add("Appointment Booked");
				statuses.add("Book Assigned");
				
				AppointmentModel appointmentModel = appointmentRepository.findByAppointmentDateAndLibrarianModelAndStatusInAndSlot(appointmentDate,librarianModel,statuses,slotModel.getSlot());
				if(appointmentModel!=null) {
					slotModel.setStatus(""+appointmentModel.getAppointmentId());
				}else {
					slotModel.setStatus("Available");
				}
				slotModel.setSlotNumber(i);
				slotList.add(slotModel);
				i++;
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return slotList;
	}

	public String bookAppintment(AppointmentModel appointmentModel, String name) {
		StudentModel studentModel = studentRepository.findByEmail(name);
		appointmentModel.setStudentModel(studentModel);
		appointmentModel.setBookedDate(""+new Date());
		appointmentModel.setStatus("Appointment Booked");
		LibrarianModel librarianModel = librarianRepository.getById(appointmentModel.getLibrarianId());
		appointmentModel.setLibrarianModel(librarianModel);
		BookModel bookModel = bookRepository.findById(appointmentModel.getBookId()).get();
		appointmentModel.setBookModel(bookModel);
		List<String> statuses = new ArrayList<>();
		statuses.add("Appointment Booked");
		statuses.add("Book Assigned");
		List<AppointmentModel> appointmentModelList = appointmentRepository.findByStudentModelAndBookModelAndAppointmentTypeAndStatusIn(studentModel,bookModel, "New Book Request",statuses);
		if(appointmentModelList.size()>0 ) {
			if(appointmentModel.getAppointmentType().equalsIgnoreCase("New Book Request")) {
				return "You are already booked appointment for this book";
			}else {
				AppointmentModel appointmentModel2= appointmentRepository.findByStudentModelAndBookModelAndAppointmentTypeAndStatus(studentModel,bookModel, "New Book Request","Book Assigned");
				appointmentModel2.setStatus("Book Return Appointment Booked");
				appointmentRepository.saveAndFlush(appointmentModel2);
			}
		}
		appointmentRepository.save(appointmentModel);
		return "Appointment Booked Successfully";
	}

	public List<AppointmentModel> getAppointments(String appointmentDate, String name) {
		List<AppointmentModel> appointmentModelList = new ArrayList<>();
		List<AppointmentModel> appointmentModelList2 = new ArrayList<>();
		UserDao userDao= userRepository.findByUsername(name);
		if(userDao.getRole().equalsIgnoreCase("Student")) {
			StudentModel studentModel = studentRepository.findByEmail(name);
			appointmentModelList = appointmentRepository.findByStudentModel(studentModel);
		}else {
			LibrarianModel librarianModel= librarianRepository.findByEmail(name);
			if(appointmentDate.equalsIgnoreCase("")) {
				appointmentModelList = appointmentRepository.findByLibrarianModel(librarianModel);
			}else {
				appointmentModelList = appointmentRepository.findByLibrarianModelAndAppointmentDateOrderBySlotNumberAsc(librarianModel,appointmentDate);
			}
		}
		Iterator<AppointmentModel> appointmentIterator = appointmentModelList.iterator();
		while(appointmentIterator.hasNext()) {
			AppointmentModel appointmentModel = appointmentIterator.next();
			BookModel bookModel = appointmentModel.getBookModel();
			try {
				File file=new File(bookdImagePath+"/"+bookModel.getPicture());
			    InputStream in = new FileInputStream(file);
			    bookModel.setPicture(Base64.getEncoder().encodeToString(IOUtils.toByteArray(in)));
			    
			} catch (Exception e) {
				System.out.println(e);
			}
			appointmentModel.setBookModel(bookModel);
			appointmentModelList2.add(appointmentModel);
		}
		
		return appointmentModelList2;
	}

	public String setStatus(String appointmentId, String status) {
		AppointmentModel appointmentModel = appointmentRepository.findById(Long.parseLong(appointmentId)).get();
		appointmentModel.setStatus(status);
		if(status.equalsIgnoreCase("Book Assigned")) {
			if(appointmentModel.getBookModel().getAvailableBooks()>0) {
				BookModel bookModel =appointmentModel.getBookModel();
				bookModel.setAvailableBooks(bookModel.getAvailableBooks()-1);
				bookRepository.saveAndFlush(bookModel);
				appointmentModel.setIssuedDate(""+LocalDate.now().plusDays(0));
				appointmentModel.setReturnDate(""+LocalDate.now().plusDays(15));
			}
		}
		if(status.equalsIgnoreCase("Book Returned")) {
			if(appointmentModel.getBookModel().getAvailableBooks()>0) {
				BookModel bookModel =appointmentModel.getBookModel();
				bookModel.setAvailableBooks(bookModel.getAvailableBooks()+1);
				bookRepository.saveAndFlush(bookModel);
			}
		}
		appointmentRepository.saveAndFlush(appointmentModel);
		return status;
	}
	
	
}
