package library.appointment.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import library.appointment.model.JwtRequest;
import library.appointment.model.JwtResponse;
import library.appointment.model.LibrarianModel;
import library.appointment.model.StudentModel;
import library.appointment.model.UserDao;
import library.appointment.model.UserDto;
import library.appointment.repositories.LibrarianRepository;
import library.appointment.repositories.StudentRepository;
import library.appointment.repositories.UserRepository;
import library.appointment.security.JwtTokenUtil;
import library.appointment.services.JwtUserDetailsService;



@RestController
public class JwtAuthenticationController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsService userDetailsService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private LibrarianRepository librarianRepository;
	
	@Autowired
	private StudentRepository studentRepository;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {
		System.out.println(authenticationRequest.getUserType());
		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());	
		UserDao userDao = userRepository.findByUsername(authenticationRequest.getUsername());
		System.out.println(userDao.getRole()+"2");
		if(!authenticationRequest.getUserType().equalsIgnoreCase(userDao.getRole())) {
			return ResponseEntity.ok(new String("Invalid Role"));
		}else if(userDao.getRole().equalsIgnoreCase("Librarian")) {
		 	LibrarianModel librarianModel = librarianRepository.findByEmail(authenticationRequest.getUsername());
		 	System.out.println(librarianModel.getStatus());
		 	if(librarianModel.getStatus().equalsIgnoreCase("Unauthorized")) {
		 		return ResponseEntity.ok(new String("You are Unauthorized"));
		 	}
		}else if(userDao.getRole().equalsIgnoreCase("Student")) {
		 	StudentModel studentModel = studentRepository.findByEmail(authenticationRequest.getUsername());
		 	if(studentModel.getStatus().equalsIgnoreCase("Unauthorized")) {
		 		return ResponseEntity.ok(new String("You are Unauthorized"));
		 	}
		}
		final String token = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new JwtResponse(token));
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody UserDto user) throws Exception {
		return ResponseEntity.ok(userDetailsService.save(user));
	}

	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
}