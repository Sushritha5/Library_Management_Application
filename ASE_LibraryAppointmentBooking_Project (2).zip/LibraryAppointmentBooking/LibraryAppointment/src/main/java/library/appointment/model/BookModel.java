package library.appointment.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Book")
public class BookModel {
	@Id
    @GeneratedValue
	private long bookId;
	@NotBlank
	private String bookName;

	private long availableBooks;
	@NotBlank
	private String author;
	@NotBlank
	private String published;
	@NotBlank
	private String aboutBook;
	@NotBlank
	private String picture;
	
	@Transient
	private long categoryId;
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "categoryId")
	private CategoryModel categoryModel;
	
	@Transient
	private long librarianId;
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "librarianId")
	private LibrarianModel librarianModel;
	
	
	public long getBookId() {
		return bookId;
	}
	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public long getAvailableBooks() {
		return availableBooks;
	}
	public void setAvailableBooks(long availableBooks) {
		this.availableBooks = availableBooks;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublished() {
		return published;
	}
	public void setPublished(String published) {
		this.published = published;
	}
	public String getAboutBook() {
		return aboutBook;
	}
	public void setAboutBook(String aboutBook) {
		this.aboutBook = aboutBook;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public long getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}
	public CategoryModel getCategoryModel() {
		return categoryModel;
	}
	public void setCategoryModel(CategoryModel categoryModel) {
		this.categoryModel = categoryModel;
	}
	public long getLibrarianId() {
		return librarianId;
	}
	public void setLibrarianId(long librarianId) {
		this.librarianId = librarianId;
	}
	public LibrarianModel getLibrarianModel() {
		return librarianModel;
	}
	public void setLibrarianModel(LibrarianModel librarianModel) {
		this.librarianModel = librarianModel;
	}
	
	
}
