package library.appointment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryAppointmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryAppointmentApplication.class, args);
	}

}
