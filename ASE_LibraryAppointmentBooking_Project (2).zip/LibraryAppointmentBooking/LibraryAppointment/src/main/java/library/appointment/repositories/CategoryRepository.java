package library.appointment.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import library.appointment.model.CategoryModel;
@Repository
public interface CategoryRepository extends JpaRepository<CategoryModel, Long>{


	CategoryModel findByCategoryName(String categoryName);

}
