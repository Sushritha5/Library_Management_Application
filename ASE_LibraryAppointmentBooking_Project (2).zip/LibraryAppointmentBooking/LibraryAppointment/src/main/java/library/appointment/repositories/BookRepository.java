package library.appointment.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import library.appointment.model.BookModel;
import library.appointment.model.CategoryModel;
import library.appointment.model.LibrarianModel;
@Repository
public interface BookRepository extends JpaRepository<BookModel, Long>{

	List<BookModel> findByBookNameLikeOrAuthorLike(String string, String string2);


	List<BookModel> findByCategoryModel(CategoryModel categoryModel);


	List<BookModel> findByCategoryModelAndBookNameLikeOrAuthorLike(CategoryModel categoryModel, String string,
			String string2);


	List<BookModel> findByLibrarianModel(LibrarianModel librarianModel);


	List<BookModel> findByLibrarianModelAndBookNameLikeOrAuthorLike(LibrarianModel librarianModel, String string,
			String string2);


	List<BookModel> findByLibrarianModelAndCategoryModel(LibrarianModel librarianModel, CategoryModel categoryModel);


	List<BookModel> findByLibrarianModelAndCategoryModelAndBookNameLikeOrAuthorLike(LibrarianModel librarianModel,
			CategoryModel categoryModel, String string, String string2);

}
