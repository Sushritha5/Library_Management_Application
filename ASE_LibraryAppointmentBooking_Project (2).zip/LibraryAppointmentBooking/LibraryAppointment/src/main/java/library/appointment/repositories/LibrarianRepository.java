package library.appointment.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import library.appointment.model.LibrarianModel;
import library.appointment.model.StudentModel;
@Repository
public interface LibrarianRepository extends JpaRepository<LibrarianModel, Long> {

	List<StudentModel> findByEmailOrPhone(String email, String phone);

	LibrarianModel findByEmail(String username);


}
