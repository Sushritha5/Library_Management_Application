package library.appointment.model;

public class SlotModel {
	private long slotNumber;
	private String slot;
	private String status;
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getSlotNumber() {
		return slotNumber;
	}
	public void setSlotNumber(long slotNumber) {
		this.slotNumber = slotNumber;
	}
	
	
}
