package library.appointment.controllers;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import library.appointment.model.AppointmentModel;
import library.appointment.model.SlotModel;
import library.appointment.services.AppointmentService;

@RestController
public class AppointmentController {
	@Autowired
	private AppointmentService appointmentService;
	
	@GetMapping("/slots")
	public List<SlotModel> getSlot(@RequestParam String appointmentDate, @RequestParam String librarianId, Principal principal){
		return appointmentService.getSlots(librarianId, appointmentDate, principal.getName());
	}
	
	@PostMapping("/appointment")
	public String bookAppintment(@RequestBody AppointmentModel appointmentModel, Principal principal) {
		return appointmentService.bookAppintment(appointmentModel,principal.getName());
	}
	
	@GetMapping("/appointment")
	public List<AppointmentModel> getAppointments(@RequestParam String appointmentDate, Principal principal){
		return appointmentService.getAppointments(appointmentDate, principal.getName());
	}
	
	@GetMapping("/setStatus")
	public String setStatus(@RequestParam String appointmentId,@RequestParam String status) {
		return appointmentService.setStatus(appointmentId,status);
	}
}
