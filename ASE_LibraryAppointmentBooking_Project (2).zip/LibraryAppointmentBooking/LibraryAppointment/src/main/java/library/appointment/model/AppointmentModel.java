package library.appointment.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Appointment")
public class AppointmentModel {
	@Id
    @GeneratedValue
	private long appointmentId;
	@Transient
	private long bookId;
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "bookId")
	private BookModel bookModel;
	@Transient
	private long studentId;
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "studentId")
	private StudentModel studentModel;
	@Transient
	private long librarianId;
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "librarianId")
	private LibrarianModel librarianModel;
	@NotBlank
	private String appointmentDate;
	@NotBlank
	private String slot;
	private long slotNumber;
	@NotBlank
	private String bookedDate;
	@NotBlank
	private String appointmentType;
	
	private String issuedDate;

	private String returnDate;
	
	@NotBlank
	private String status;
	
	
	public long getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(long appointmentId) {
		this.appointmentId = appointmentId;
	}
	public long getBookId() {
		return bookId;
	}
	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	public BookModel getBookModel() {
		return bookModel;
	}
	public void setBookModel(BookModel bookModel) {
		this.bookModel = bookModel;
	}
	public long getStudentId() {
		return studentId;
	}
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	public StudentModel getStudentModel() {
		return studentModel;
	}
	public void setStudentModel(StudentModel studentModel) {
		this.studentModel = studentModel;
	}
	public long getLibrarianId() {
		return librarianId;
	}
	public void setLibrarianId(long librarianId) {
		this.librarianId = librarianId;
	}
	public LibrarianModel getLibrarianModel() {
		return librarianModel;
	}
	public void setLibrarianModel(LibrarianModel librarianModel) {
		this.librarianModel = librarianModel;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getBookedDate() {
		return bookedDate;
	}
	public void setBookedDate(String bookedDate) {
		this.bookedDate = bookedDate;
	}
	public String getAppointmentType() {
		return appointmentType;
	}
	public void setAppointmentType(String appointmentType) {
		this.appointmentType = appointmentType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getSlotNumber() {
		return slotNumber;
	}
	public void setSlotNumber(long slotNumber) {
		this.slotNumber = slotNumber;
	}
	public String getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	
	
}
