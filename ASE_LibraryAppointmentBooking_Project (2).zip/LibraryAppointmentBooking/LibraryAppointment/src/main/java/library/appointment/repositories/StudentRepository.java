package library.appointment.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import library.appointment.model.StudentModel;
@Repository
public interface StudentRepository extends JpaRepository<StudentModel, Long> {

	List<StudentModel> findByEmailOrPhone(String email, String phone);

	StudentModel findByEmail(String username);

}
