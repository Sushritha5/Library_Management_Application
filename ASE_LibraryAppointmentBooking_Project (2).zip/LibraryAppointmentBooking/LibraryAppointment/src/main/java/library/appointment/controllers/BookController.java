package library.appointment.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import library.appointment.model.BookModel;
import library.appointment.services.BookService;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

@RestController
public class BookController {
	@Autowired
	private BookService bookService;
	@Value("${bookdImagePath}")
	String bookdImagePath ;
	
	@RequestMapping(value = "/book", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String signupFarmer(
			@RequestParam(name = "file") MultipartFile multipartFile,
			@RequestParam String bookName,
			@RequestParam String categoryId,
			@RequestParam String availableBooks,
			@RequestParam String author,
			@RequestParam String published,
			@RequestParam String aboutBook,
			Principal principal
			) {
		String message = null;
		try {
			File uploadedFile = new File(bookdImagePath, multipartFile.getOriginalFilename());
			uploadedFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(uploadedFile);
			fos.write(multipartFile.getBytes());
			fos.close();
			
			BookModel bookModel=new BookModel();
			bookModel.setBookName(bookName);
			bookModel.setCategoryId(Long.parseLong(categoryId));
			bookModel.setAvailableBooks(Long.parseLong(availableBooks));
			bookModel.setAuthor(author);
			bookModel.setPublished(published);
			bookModel.setAboutBook(aboutBook);
			bookModel.setPicture(multipartFile.getOriginalFilename());
			return bookService.addBook(bookModel, principal.getName());
			
		} catch (Exception e) {
			System.out.println(e);
			return "Fails to upload the file";
		}
	}
	
	@GetMapping("/book")
	public List<BookModel> getBooks(@RequestParam String librarianId, @RequestParam String categoryId, @RequestParam String bookName,Principal principal){
		return bookService.getBooks(librarianId, categoryId, bookName, principal.getName());
	}
}
