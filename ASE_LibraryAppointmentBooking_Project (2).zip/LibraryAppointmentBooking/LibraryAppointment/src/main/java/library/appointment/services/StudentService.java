package library.appointment.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import library.appointment.model.StudentModel;
import library.appointment.model.UserDao;
import library.appointment.model.UserDto;
import library.appointment.repositories.StudentRepository;
import library.appointment.repositories.UserRepository;

@Service
public class StudentService {
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private JwtUserDetailsService userDetailsService;

	public String studentRegistration(StudentModel studentModel) {
		try {
			UserDao userDao = userRepository.findByUsername(studentModel.getEmail());
			if(userDao!=null) {
				return "Duplicate Email Addresss";
			}
			List<StudentModel> studentModelList = studentRepository.findByEmailOrPhone(studentModel.getEmail(),studentModel.getPhone());
			if(studentModelList.size()>0) {
				return "Email or Phone Number Duplicate";
			}
			
			UserDto user=new UserDto();
			user.setUsername(studentModel.getEmail());
			user.setPassword(studentModel.getPassword());
			user.setRole("Student");
			studentModel.setStatus("Unauthorized");
			studentModel.setUserDao(userDetailsService.save(user));
			studentRepository.save(studentModel);
			return "Your Student Account Created Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Exception occurred "+e;
		}
	}

	public List<StudentModel> getStudents() {
		List<StudentModel> studentModelList = studentRepository.findAll();
		Collections.reverse(studentModelList);
		return studentModelList;
	}

	public String activateStudent(String studentId) {
		StudentModel  studentModel = studentRepository.findById(Long.parseLong(studentId)).get();
		studentModel.setStatus("Authorized");
		studentRepository.saveAndFlush(studentModel);
		return "Student Account Authorized";
	}
}
