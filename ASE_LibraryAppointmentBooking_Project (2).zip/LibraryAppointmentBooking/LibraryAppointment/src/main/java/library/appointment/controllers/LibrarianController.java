package library.appointment.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import library.appointment.model.LibrarianModel;
import library.appointment.model.StudentModel;
import library.appointment.repositories.LibrarianRepository;
import library.appointment.services.LibrarianService;

@RestController
public class LibrarianController {
	@Autowired
	private LibrarianService librarianService;
	
	@PostMapping("/lreg")
	public String librarianRegistration(@RequestBody LibrarianModel librarianModel) {
		return librarianService.librarianRegistration(librarianModel);
	}
	
	@GetMapping("/librarian")
	public List<LibrarianModel> getLibrarians(){
		return librarianService.getLibrarians();
	}
	
	@GetMapping("/librarianActivate")
	public String activateLibrarian(@RequestParam String librarianId) {
		return librarianService.activateLibrarian(librarianId);
	}
}
