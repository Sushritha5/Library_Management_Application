package library.appointment.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import library.appointment.services.CommentService;

@RestController
public class CommentController {
	@Autowired
	private CommentService commentService;
}
