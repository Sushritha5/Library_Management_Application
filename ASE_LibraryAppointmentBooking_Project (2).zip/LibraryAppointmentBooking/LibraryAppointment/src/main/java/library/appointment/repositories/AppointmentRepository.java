package library.appointment.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import library.appointment.model.AppointmentModel;
import library.appointment.model.BookModel;
import library.appointment.model.LibrarianModel;
import library.appointment.model.StudentModel;
@Repository
public interface AppointmentRepository extends JpaRepository<AppointmentModel, Long> {

	AppointmentModel findByAppointmentDateAndLibrarianModelAndStatusInAndSlot(String appointmentDate,
			LibrarianModel librarianModel, List<String> statuses, String slot);

	List<AppointmentModel> findByStudentModel(StudentModel studentModel);

	List<AppointmentModel> findByLibrarianModel(LibrarianModel librarianModel);


	List<AppointmentModel> findByLibrarianModelAndAppointmentDateOrderBySlotNumberAsc(LibrarianModel librarianModel,
			String appointmentDate);

	List<AppointmentModel> findByStudentModelAndBookModelAndAppointmentTypeAndStatusIn(StudentModel studentModel,
			BookModel bookModel, String string, List<String> statuses);

	AppointmentModel findByStudentModelAndBookModelAndAppointmentTypeAndStatus(StudentModel studentModel,
			BookModel bookModel, String string, String string2);


}
