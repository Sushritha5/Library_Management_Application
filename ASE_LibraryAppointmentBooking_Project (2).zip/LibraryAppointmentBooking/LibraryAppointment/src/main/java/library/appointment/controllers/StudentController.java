package library.appointment.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import library.appointment.model.StudentModel;
import library.appointment.services.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	@PostMapping("/sreg")
	public String studentRegistration(@RequestBody StudentModel studentModel) {
		return studentService.studentRegistration(studentModel);
	}
	
	@GetMapping("/student")
	public List<StudentModel> getStudents(){
		return studentService.getStudents();
	}
	
	@GetMapping("/studentActivate")
	public String activateStudent(@RequestParam String studentId) {
		return studentService.activateStudent(studentId);
	}
	
}
