package library.appointment.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import library.appointment.model.CategoryModel;
import library.appointment.repositories.CategoryRepository;

@Service
public class CategoryService {
	@Autowired
	private CategoryRepository categoryRepository;

	public String addCategory(CategoryModel categoryModel) {
		CategoryModel categoryModel2= categoryRepository.findByCategoryName(categoryModel.getCategoryName());
		if(categoryModel2!=null) {
			return "Duplicate Category Details";
		}
		categoryRepository.save(categoryModel);
		return "Category Added Successfully";
	}

	public List<CategoryModel> getCategories() {
		List<CategoryModel> categoryModelList = categoryRepository.findAll();
		return categoryModelList;
	}
}
