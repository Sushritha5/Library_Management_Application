package library.appointment.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import library.appointment.model.LibrarianModel;
import library.appointment.model.StudentModel;
import library.appointment.model.UserDao;
import library.appointment.model.UserDto;
import library.appointment.repositories.LibrarianRepository;
import library.appointment.repositories.UserRepository;

@Service
public class LibrarianService {
	@Autowired
	private LibrarianRepository librarianRepository;
	
	@Autowired 
	private JwtUserDetailsService userDetailsService;
	
	@Autowired
	private UserRepository userRepository;

	public String librarianRegistration(LibrarianModel librarianModel) {
		try {
			UserDao userDao = userRepository.findByUsername(librarianModel.getEmail());
			if(userDao!=null) {
				return "Duplicate Email Addresss";
			}
			List<StudentModel> studentModelList = librarianRepository.findByEmailOrPhone(librarianModel.getEmail(),librarianModel.getPhone());
			if(studentModelList.size()>0) {
				return "Email or Phone Number Duplicate";
			}
			
			UserDto user=new UserDto();
			user.setUsername(librarianModel.getEmail());
			user.setPassword(librarianModel.getPassword());
			user.setRole("Librarian");
			librarianModel.setLocation(librarianModel.getLocation().toLowerCase());
			librarianModel.setStatus("Unauthorized");
			librarianModel.setUserDao(userDetailsService.save(user));
			librarianRepository.save(librarianModel);
			return "Your Librarian Account Created Successfully";
		} catch (Exception e) {
			System.out.println(e);
			return "Exception occurred "+e;
		}
	}

	public List<LibrarianModel> getLibrarians() {
		List<LibrarianModel> librarianModelList = librarianRepository.findAll();
		Collections.reverse(librarianModelList);
		return librarianModelList;
	}

	public String activateLibrarian(String librarianId) {
		LibrarianModel  librarianModel = librarianRepository.findById(Long.parseLong(librarianId)).get();
		librarianModel.setStatus("Authorized");
		librarianRepository.saveAndFlush(librarianModel);
		return "Librarian Account Authorized";
	}
}
